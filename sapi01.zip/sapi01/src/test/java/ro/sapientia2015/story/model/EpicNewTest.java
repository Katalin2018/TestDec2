package ro.sapientia2015.story.model;

import org.junit.Test;

import static junit.framework.Assert.*;

public class EpicNewTest {

	@Test
	public void testTitle(){
		Epic epic = Epic.getBuilder("Hello").build();
		assertNotNull(epic.getTitle());
	}
	
}
